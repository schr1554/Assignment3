package test.java.edu.uw.ajs;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import test.BrokerTest;

@RunWith(Suite.class)
@SuiteClasses({ BrokerTest.class })
public class BrokerTests {

}
